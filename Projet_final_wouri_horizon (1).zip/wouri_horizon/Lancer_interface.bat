@echo off
REM Lance l'interface graphique de Wouri Horizon (double-clic)
cd /d "%~dp0"
python -m wh.gui
if errorlevel 1 (
    echo.
    echo Erreur au lancement. Verifiez que Python 3.10+ est installe et dans le PATH.
    pause
)
