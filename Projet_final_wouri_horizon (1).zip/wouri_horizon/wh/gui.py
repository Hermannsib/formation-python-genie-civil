"""Couche présentation (graphique) : fenêtre de bureau Tkinter.

Lancement depuis la racine du projet :  python -m wh.gui
Les calculs viennent des mêmes couches que la ligne de commande
(services, modèle, données) : seule la présentation change.
"""
import os
import subprocess
import sys
import tkinter as tk
from tkinter import ttk, messagebox

from wh import __version__
from wh.config import charger_parametres, RAPPORTS
from wh.donnees import lire_niveau, niveaux_disponibles
from wh.services import metre, sacs_ciment, decision_coulage
from wh.rapport import ecrire_rapport

NAVY, JAUNE, VERT, ROUGE, GRIS = "#0E1F33", "#F2B705", "#2E9E5B", "#C0392B", "#5A6B7D"


def lire_pluie(texte: str) -> float:
    """Convertit la saisie de pluie ('4,5' ou '4.5') en float ; ValueError si invalide."""
    texte = texte.strip().replace(",", ".")
    if not texte:
        raise ValueError("saisie vide")
    return float(texte)


class Application(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"Wouri Horizon — Outils de chantier (v{__version__})")
        self.geometry("760x620")
        self.minsize(680, 560)
        self.params = charger_parametres()
        self.niveau = None
        self.volumes = {}
        self.sacs = 0
        self._styles()
        self._construire()
        niveaux = niveaux_disponibles()
        if niveaux:
            self.choix_niveau.set("N2" if "N2" in niveaux else niveaux[0])
            self.calculer()

    # ---------- apparence ----------
    def _styles(self):
        style = ttk.Style(self)
        if "clam" in style.theme_names():
            style.theme_use("clam")
        style.configure("Treeview", rowheight=26, font=("Segoe UI", 10))
        style.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"))
        style.configure("TButton", font=("Segoe UI", 10), padding=6)
        style.configure("Titre.TLabelframe.Label", font=("Segoe UI", 11, "bold"))

    def _construire(self):
        entete = tk.Frame(self, bg=NAVY, height=64)
        entete.pack(fill="x")
        tk.Label(entete, text="Résidence Wouri Horizon", bg=NAVY, fg="white",
                 font=("Segoe UI", 16, "bold")).pack(side="left", padx=16, pady=12)
        tk.Label(entete, text=f"Projet {self.params['projet']} · Bonamoussadi, Douala", bg=NAVY, fg=JAUNE,
                 font=("Segoe UI", 10)).pack(side="right", padx=16)

        corps = ttk.Frame(self, padding=12)
        corps.pack(fill="both", expand=True)

        # Choix du niveau
        ligne = ttk.Frame(corps)
        ligne.pack(fill="x", pady=(0, 8))
        ttk.Label(ligne, text="Niveau :", font=("Segoe UI", 11)).pack(side="left")
        self.choix_niveau = ttk.Combobox(ligne, values=niveaux_disponibles(), width=8, state="readonly")
        self.choix_niveau.pack(side="left", padx=8)
        self.choix_niveau.bind("<<ComboboxSelected>>", lambda e: self.calculer())
        ttk.Button(ligne, text="Calculer le métré", command=self.calculer).pack(side="left")

        # Tableau du métré
        cadre_metre = ttk.LabelFrame(corps, text="Métré béton", style="Titre.TLabelframe", padding=8)
        cadre_metre.pack(fill="both", expand=True)
        self.tableau = ttk.Treeview(cadre_metre, columns=("type", "repere", "dims", "volume"), show="headings", height=6)
        for col, titre, larg, ancre in (("type", "Type", 70, "center"), ("repere", "Repère", 150, "w"),
                                        ("dims", "Dimensions (m) × nb", 220, "w"), ("volume", "Volume (m³)", 110, "e")):
            self.tableau.heading(col, text=titre)
            self.tableau.column(col, width=larg, anchor=ancre)
        self.tableau.pack(fill="both", expand=True)
        self.resume = tk.StringVar(value="—")
        ttk.Label(cadre_metre, textvariable=self.resume, font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=(8, 0))

        # Décision de coulage
        cadre_coul = ttk.LabelFrame(corps, text="Décision de coulage", style="Titre.TLabelframe", padding=8)
        cadre_coul.pack(fill="x", pady=10)
        ttk.Label(cadre_coul, text="Pluie prévue (mm) :").grid(row=0, column=0, sticky="w")
        self.saisie_pluie = ttk.Entry(cadre_coul, width=10)
        self.saisie_pluie.grid(row=0, column=1, padx=8)
        self.saisie_pluie.bind("<Return>", lambda e: self.decider())
        ttk.Button(cadre_coul, text="Décider", command=self.decider).grid(row=0, column=2)
        ttk.Label(cadre_coul, text=f"Seuil : {self.params['seuil_pluie_mm']} mm · Stock magasin : "
                                   f"{self.params['stock_sacs']} sacs", foreground=GRIS).grid(row=0, column=3, padx=12, sticky="w")
        self.resultat = tk.Label(cadre_coul, text="Saisissez la pluie prévue, puis « Décider ».",
                                 font=("Segoe UI", 12, "bold"), fg=GRIS, anchor="w")
        self.resultat.grid(row=1, column=0, columnspan=4, sticky="we", pady=(10, 0))

        # Rapport
        bas = ttk.Frame(corps)
        bas.pack(fill="x")
        ttk.Button(bas, text="Enregistrer le rapport JSON", command=self.enregistrer).pack(side="left")
        ttk.Button(bas, text="Ouvrir le dossier des rapports", command=self.ouvrir_dossier).pack(side="left", padx=8)

        self.statut = tk.StringVar(value="Prêt.")
        tk.Label(self, textvariable=self.statut, anchor="w", bg="#E9EDF2", fg=NAVY, padx=10).pack(fill="x", side="bottom")

    # ---------- actions ----------
    def calculer(self):
        nom = self.choix_niveau.get()
        if not nom:
            return
        try:
            self.niveau = lire_niveau(nom)
        except FileNotFoundError:
            messagebox.showerror("Niveau introuvable", f"Aucun fichier de données pour le niveau {nom}.")
            return
        except (ValueError, KeyError) as err:
            messagebox.showerror("Données invalides", f"Le fichier du niveau {nom} contient une erreur :\n{err}")
            return
        self.volumes = metre(self.niveau)
        self.sacs = sacs_ciment(self.niveau.volume, self.params["dosage_kg_m3"], self.params["sac_kg"])
        self.tableau.delete(*self.tableau.get_children())
        for e in self.niveau:
            dims = f"{e.b:g} × {e.h:g} × {e.l:g}  × {e.nb}"
            self.tableau.insert("", "end", values=(e.type, e.repere, dims, f"{e.volume:.2f}"))
        self.resume.set(f"Niveau {self.niveau.nom} : {len(self.niveau)} types · "
                        f"{self.niveau.volume:.2f} m³ · {self.sacs} sacs de ciment")
        self.resultat.config(text="Saisissez la pluie prévue, puis « Décider ».", fg=GRIS)
        self.statut.set(f"Métré du niveau {self.niveau.nom} calculé.")

    def decider(self):
        if self.niveau is None:
            return
        try:
            pluie = lire_pluie(self.saisie_pluie.get())
        except ValueError:
            messagebox.showwarning("Saisie invalide", "Entrez la pluie en millimètres, par exemple 4,5.")
            return
        ok, raison = decision_coulage(pluie, self.sacs, self.params["stock_sacs"], self.params["seuil_pluie_mm"])
        self.resultat.config(text=("✔ AUTORISÉ : " if ok else "✖ REFUSÉ : ") + raison, fg=VERT if ok else ROUGE)
        self.statut.set(f"Décision de coulage pour {self.niveau.nom} avec {pluie:g} mm de pluie.")

    def enregistrer(self):
        if self.niveau is None:
            return
        chemin = ecrire_rapport(self.niveau, self.volumes, self.sacs)
        self.statut.set(f"Rapport enregistré : {chemin.name}")
        messagebox.showinfo("Rapport enregistré", f"Le rapport a été enregistré :\n{chemin}")

    def ouvrir_dossier(self):
        RAPPORTS.mkdir(parents=True, exist_ok=True)
        try:
            if sys.platform.startswith("win"):
                os.startfile(RAPPORTS)
            elif sys.platform == "darwin":
                subprocess.run(["open", str(RAPPORTS)], check=False)
            else:
                subprocess.run(["xdg-open", str(RAPPORTS)], check=False)
        except OSError:
            messagebox.showinfo("Dossier des rapports", str(RAPPORTS))


def main():
    Application().mainloop()


if __name__ == "__main__":
    main()
