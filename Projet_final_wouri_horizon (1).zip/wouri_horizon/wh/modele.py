"""Couche modèle : les objets du chantier."""
from dataclasses import dataclass, field


@dataclass
class Element:
    """Un type d'élément en béton armé : nb éléments identiques de section b × h et de longueur l."""
    repere: str
    type: str
    b: float   # m
    h: float   # m
    l: float   # m
    nb: int = 1

    def __post_init__(self):
        if min(self.b, self.h, self.l) <= 0:
            raise ValueError(f"{self.repere} : dimension nulle ou négative")
        if self.nb <= 0:
            raise ValueError(f"{self.repere} : nombre d'éléments invalide ({self.nb})")

    @property
    def volume(self) -> float:
        """Volume de béton en m³."""
        return self.b * self.h * self.l * self.nb


@dataclass
class Niveau:
    """Un niveau du bâtiment, composé d'éléments (composition)."""
    nom: str
    elements: list[Element] = field(default_factory=list)

    def ajouter(self, element: Element) -> None:
        self.elements.append(element)

    def __len__(self) -> int:
        return len(self.elements)

    def __iter__(self):
        return iter(self.elements)

    @property
    def volume(self) -> float:
        """Volume total du niveau en m³."""
        return sum(e.volume for e in self)
