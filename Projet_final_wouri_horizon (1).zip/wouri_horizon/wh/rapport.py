"""Couche données (sortie) : enregistrement des rapports en JSON."""
import json
from datetime import date
from pathlib import Path
from wh.config import RAPPORTS
from wh.modele import Niveau


def ecrire_rapport(niveau: Niveau, volumes: dict[str, float], sacs: int,
                   dossier: Path = RAPPORTS) -> Path:
    """Enregistre rapports/rapport_<niveau>.json et renvoie son chemin."""
    dossier.mkdir(parents=True, exist_ok=True)
    chemin = dossier / f"rapport_{niveau.nom.lower()}.json"
    contenu = {"niveau": niveau.nom, "date": date.today().isoformat(),
               "volumes_m3": volumes, "total_m3": round(niveau.volume, 2), "sacs": sacs}
    with open(chemin, "w", encoding="utf-8") as f:
        json.dump(contenu, f, indent=2, ensure_ascii=False)
    return chemin
