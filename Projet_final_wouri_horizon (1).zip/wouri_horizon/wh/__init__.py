"""wh — outils de chantier de la Résidence Wouri Horizon (Bonamoussadi, Douala).

Projet final de la formation « Python appliqué au génie civil ».
Lancement depuis la racine du projet :  python -m wh --help
"""
__version__ = "1.0"
