"""Couche configuration : chemins du projet et paramètres de chantier."""
import json
from pathlib import Path

# Racine du projet, calculée à partir de l'emplacement de ce fichier :
# le logiciel fonctionne quel que soit le dossier où il est installé.
RACINE = Path(__file__).resolve().parent.parent
DONNEES = RACINE / "donnees"
RAPPORTS = RACINE / "rapports"


def charger_parametres() -> dict:
    """Lit donnees/parametres_wh.json (dosage, taille des sacs, seuil de pluie, stock)."""
    with open(DONNEES / "parametres_wh.json", encoding="utf-8") as f:
        return json.load(f)
