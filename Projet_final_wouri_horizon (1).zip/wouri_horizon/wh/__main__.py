"""Couche présentation : la ligne de commande du logiciel wh.

Exemples (depuis la racine du projet) :
    python -m wh metre   --niveau N2
    python -m wh coulage --niveau N2 --pluie 4.5
    python -m wh rapport --niveau N2
"""
import argparse
import logging
import sys
from wh.config import charger_parametres
from wh.donnees import lire_niveau, niveaux_disponibles
from wh.services import metre, sacs_ciment, decision_coulage
from wh.rapport import ecrire_rapport

logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")
log = logging.getLogger("wh")


def creer_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="wh", description="Outils de chantier Wouri Horizon")
    sous = parser.add_subparsers(dest="commande", required=True)
    for nom, aide in (("metre", "métré béton d'un niveau"),
                      ("coulage", "décision de coulage selon la pluie et le stock"),
                      ("rapport", "enregistre le rapport JSON d'un niveau")):
        sp = sous.add_parser(nom, help=aide)
        sp.add_argument("--niveau", required=True, help="RC, N1, N2...")
        if nom == "coulage":
            sp.add_argument("--pluie", type=float, required=True, help="pluie prévue en mm")
    return parser


def main() -> int:
    args = creer_parser().parse_args()
    p = charger_parametres()
    try:
        niveau = lire_niveau(args.niveau)
    except FileNotFoundError:
        log.error("Niveau %s introuvable. Niveaux disponibles : %s",
                  args.niveau, ", ".join(niveaux_disponibles()))
        return 1
    except (ValueError, KeyError) as err:
        log.error("Données invalides pour le niveau %s : %s", args.niveau, err)
        return 1

    volumes = metre(niveau)
    sacs = sacs_ciment(niveau.volume, p["dosage_kg_m3"], p["sac_kg"])

    if args.commande == "metre":
        for t, v in volumes.items():
            print(f"  {t:<3}{v:>8.2f} m³")
        print(f"{niveau.nom} : {len(niveau)} types, {niveau.volume:.2f} m³, {sacs} sacs")
    elif args.commande == "coulage":
        ok, raison = decision_coulage(args.pluie, sacs, p["stock_sacs"], p["seuil_pluie_mm"])
        print(("AUTORISÉ" if ok else "REFUSÉ") + " : " + raison)
    else:
        chemin = ecrire_rapport(niveau, volumes, sacs)
        log.info("Rapport enregistré : %s", chemin.name)
    return 0


if __name__ == "__main__":
    sys.exit(main())
