"""Couche services : les calculs métier, sans lecture de fichier ni affichage."""
import math
from wh.modele import Niveau


def metre(niveau: Niveau) -> dict[str, float]:
    """Volume (m³) de chaque type d'élément du niveau."""
    return {e.type: round(e.volume, 2) for e in niveau}


def sacs_ciment(v_m3: float, dosage: float, sac_kg: float) -> int:
    """Nombre de sacs de ciment à commander (arrondi au supérieur)."""
    return math.ceil(v_m3 * dosage / sac_kg)


def decision_coulage(pluie_mm: float, besoin: int, stock: int, seuil: float = 10) -> tuple[bool, str]:
    """Renvoie (autorisé, raison) pour un coulage.

    Règles : on reporte si la pluie prévue atteint le seuil ;
    on refuse si les sacs nécessaires dépassent le stock du magasin.
    """
    if pluie_mm < 0:
        return False, f"pluie négative ({pluie_mm} mm) : saisie incohérente"
    if pluie_mm >= seuil:
        return False, f"pluie {pluie_mm} mm >= {seuil} mm"
    if besoin > stock:
        return False, f"ciment insuffisant ({besoin} > {stock})"
    return True, "coulage autorisé"
