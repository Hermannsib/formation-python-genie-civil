"""Couche données : lecture des fichiers CSV du bureau d'études."""
import csv
from wh.config import DONNEES
from wh.modele import Element, Niveau


def lire_niveau(nom: str) -> Niveau:
    """Construit le Niveau à partir de donnees/elements_<nom>.csv (séparateur ;)."""
    chemin = DONNEES / f"elements_{nom.lower()}.csv"
    niveau = Niveau(nom.upper())
    with open(chemin, encoding="utf-8") as f:
        for r in csv.DictReader(f, delimiter=";"):
            niveau.ajouter(Element(r["id"], r["type"],
                                   float(r["b_m"].replace(",", ".")),
                                   float(r["h_m"].replace(",", ".")),
                                   float(r["l_m"].replace(",", ".")),
                                   int(r["nb"])))
    return niveau


def niveaux_disponibles() -> list[str]:
    """Liste les niveaux pour lesquels un fichier CSV existe."""
    return sorted(p.stem.removeprefix("elements_").upper() for p in DONNEES.glob("elements_*.csv"))
