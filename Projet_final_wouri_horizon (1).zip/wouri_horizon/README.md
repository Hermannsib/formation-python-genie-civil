# wh — Outils de chantier de la Résidence Wouri Horizon

Projet final de la formation **Python appliqué au génie civil**
(Module 14 · Leçon 2). Chantier fil rouge : immeuble R+4, Bonamoussadi, Douala.

## Ce que fait le logiciel

| Commande | Rôle |
|---|---|
| `python -m wh metre --niveau N2` | Métré béton par type d'élément, volume total, sacs de ciment |
| `python -m wh coulage --niveau N2 --pluie 4.5` | Autorise ou refuse le coulage (pluie ≥ seuil, stock de ciment) |
| `python -m wh rapport --niveau N2` | Enregistre `rapports/rapport_n2.json`, daté |

Niveaux fournis : `RC`, `N1`, `N2` (fichiers `donnees/elements_*.csv`).
Paramètres (dosage, sacs, seuil de pluie, stock) : `donnees/parametres_wh.json`.

## Prérequis

Python 3.10 ou plus récent. Aucune bibliothèque externe pour le logiciel ;
`pytest` seulement pour les tests.

## Installation (Windows, PowerShell)

```powershell
cd wouri_horizon
python -m venv .venv
.venv\Scripts\activate          # si refusé : Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
pip install -r requirements.txt
```

Sous Linux / macOS : `source .venv/bin/activate` à la place de la 3e ligne.

## Interface graphique (fenêtre de bureau)

Double-cliquez sur **`Lancer_interface.bat`**, ou tapez depuis la racine :

```powershell
python -m wh.gui
```

La fenêtre permet de choisir le niveau, voir le métré, décider du coulage
(la pluie peut s'écrire 4,5 ou 4.5) et enregistrer le rapport JSON.
Tkinter est inclus dans l'installateur officiel de Python pour Windows.

## Utilisation en ligne de commande

Toujours **depuis le dossier `wouri_horizon`** (la racine du projet) :

```powershell
python -m wh --help
python -m wh metre --niveau N2
python -m wh coulage --niveau N2 --pluie 4.5
python -m wh coulage --niveau N2 --pluie 12
python -m wh rapport --niveau N2
```

Ne lancez pas `python wh/__main__.py` : les imports absolus `from wh...`
échouent (ModuleNotFoundError), comme expliqué au module 14.

## Tests

```powershell
python -m pytest -q
```

## Architecture (couches)

```
wh/__main__.py   présentation : ligne de commande (argparse, logging)
wh/gui.py        présentation : fenêtre de bureau (Tkinter)
wh/services.py   services     : metre(), sacs_ciment(), decision_coulage()
wh/modele.py     modèle       : dataclasses Element et Niveau
wh/donnees.py    données      : lecture des CSV
wh/rapport.py    données      : écriture des rapports JSON
wh/config.py     configuration: chemins et paramètres
```

## Ajouter un niveau

Créez `donnees/elements_n3.csv` (séparateur `;`, colonnes
`id;type;b_m;h_m;l_m;nb`, dimensions en mètres), puis :
`python -m wh metre --niveau N3`.

Note : les quantités et règles sont pédagogiques ; un vrai dimensionnement
suit les normes en vigueur et doit être vérifié par un ingénieur.
