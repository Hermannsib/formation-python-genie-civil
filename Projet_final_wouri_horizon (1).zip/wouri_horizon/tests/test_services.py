from wh.services import sacs_ciment, decision_coulage


def test_sacs():
    assert sacs_ciment(57.6, 350, 50) == 404


def test_pluie_faible_autorise():
    ok, raison = decision_coulage(4.5, 567, 600)
    assert ok and raison == "coulage autorisé"


def test_seuil_exact_refuse():
    ok, _ = decision_coulage(10, 567, 600)
    assert ok is False


def test_stock_insuffisant():
    ok, raison = decision_coulage(2, 650, 600)
    assert not ok and "ciment" in raison


def test_pluie_negative_refusee():
    ok, raison = decision_coulage(-3, 567, 600)
    assert not ok and "incohérente" in raison
