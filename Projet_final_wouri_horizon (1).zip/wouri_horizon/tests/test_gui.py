import pytest
from wh.gui import lire_pluie


def test_lire_pluie_virgule():
    assert lire_pluie(" 4,5 ") == 4.5


def test_lire_pluie_invalide():
    with pytest.raises(ValueError):
        lire_pluie("abc")


def test_lire_pluie_vide():
    with pytest.raises(ValueError):
        lire_pluie("")
