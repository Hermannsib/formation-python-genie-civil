import json
import pytest
from pytest import approx
from wh.modele import Element, Niveau
from wh.donnees import lire_niveau, niveaux_disponibles
from wh.services import metre
from wh.rapport import ecrire_rapport


def test_volume_element():
    assert Element("PT", "PT", 0.30, 0.30, 3.00, 20).volume == approx(5.4)


def test_dimension_negative_refusee():
    with pytest.raises(ValueError):
        Element("X", "PT", 0.30, -0.30, 3.00)


def test_niveau_composition():
    n = Niveau("T")
    n.ajouter(Element("A", "DL", 15, 0.16, 24))
    n.ajouter(Element("B", "PT", 0.3, 0.3, 3, 20))
    assert len(n) == 2 and n.volume == approx(63.0)


def test_lecture_n2():
    n2 = lire_niveau("n2")
    assert n2.nom == "N2" and len(n2) == 4
    assert n2.volume == approx(81.0)
    assert metre(n2) == {"DL": 57.6, "PT": 5.4, "PP": 12.0, "PS": 6.0}


def test_niveaux_disponibles():
    assert niveaux_disponibles() == ["N1", "N2", "RC"]


def test_rapport(tmp_path):
    n2 = lire_niveau("N2")
    chemin = ecrire_rapport(n2, metre(n2), 567, dossier=tmp_path)
    contenu = json.loads(chemin.read_text(encoding="utf-8"))
    assert contenu["niveau"] == "N2" and contenu["sacs"] == 567 and contenu["total_m3"] == 81.0
